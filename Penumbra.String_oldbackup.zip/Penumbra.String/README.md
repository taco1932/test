# ByteString

This is an auxiliary repository for dealing with owned or unowned byte strings when working with Final Fantasy XIV.
For more information, see the [main repo](https://github.com/xivdev/Penumbra).