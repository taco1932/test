using VfxEditor.CutbFormat;
using VfxEditor.Formats.SgbFormat;

namespace VfxEditor.Select.Formats {
    public class CutbSelectDialog : SelectDialog {
        public CutbSelectDialog( string id, CutbManager manager, bool isSourceDialog ) : base( id, "cutb", manager, isSourceDialog ) {
            GameTabs.AddRange( new SelectTab[]{

            } );
        }
    }
}