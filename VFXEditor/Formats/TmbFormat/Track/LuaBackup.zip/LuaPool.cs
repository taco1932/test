using System.Collections.Generic;

namespace VfxEditor.TmbFormat.Root {
    public class LuaPool {
        public readonly int Id;
        public readonly int Size;
        public readonly Dictionary<int, string> Names;

        public LuaPool( int id, int maxSize, Dictionary<int, string> names ) {
            Id = id;
            Size = maxSize;
            Names = names;
        }

        public static readonly LuaPool Pool1 = new( 1, 12000, new() {
            { 0x00, "[CUTSCENE] Game Language" },
            { 0x01, "[CUTSCENE] Caption Language" },
            { 0x02, "[CUTSCENE] Voice Language" },
            { 0x03, "[CUTSCENE] Skeleton ID" },
            { 0x04, "[CUTSCENE] Starting Town" },
            { 0x09, "[CUTSCENE] Quest Progression" },
            { 0x0E, "[CUTSCENE] Dialogue Selection" },
            { 0x0F, "[CUTSCENE] (Unknown)" },
            { 0x10, "[CUTSCENE] Legacy Player" },
            { 0x12, "[CUTSCENE] Class/Job" },
            { 0x13, "Is Player Character" },
            { 0x14, "[CUTSCENE] (Unknown)" },
            { 0x1B, "[CUTSCENE] Gender" },
            { 0x1C, "[CUTSCENE] (Unknown)" },
            { 0x23, "[CUTSCENE] Is Gatherer" },
            { 0x24, "[CUTSCENE] Is Crafter" },
            { 0x25, "Is Mount" },
            { 0x26, "Mounted" },
            { 0x27, "Swimming" },
            { 0x28, "Underwater" },
            { 0x29, "Class/Job" },
            { 0x2D, "[CUTSCENE] (Unknown)" },
            { 0x33, "Mount ID" },
            { 0x34, "Character State" },
            { 0x39, "GPose" },
            { 0x3C, "Skeleton ID" },
            { 0x3D, "Mount Flying" },
            { 0x3D, "Mount Flying" },
            { 0x65A, "Mouse Drag" },
            { 0x65B, "Window Focus" },
            { 0x65C, "Cursor Type / Hover State?" },
            { 0x70C, "Cursor Type / Hover State?" },
            { 0x70D, "Cursor X Pos" },
            { 0x70E, "Cursor Y Pos" },
            { 0x710, "Cursor Type / Hover State?" },
            { 0x711, "Cursor X Pos" },
            { 0x712, "Cursor Y Pos" },
            { 0x714, "Cursor Type / Hover State?" },
            { 0x715, "Cursor X Pos" },
            { 0x716, "Cursor Y Pos" },
            { 0x718, "Cursor Type / Hover State?" },
            { 0x719, "Cursor X Pos" },
            { 0x71A, "Cursor Y Pos" },
            { 0x71C, "Cursor Type / Hover State?" },
            { 0x71D, "Cursor X Pos" },
            { 0x71E, "Cursor Y Pos" },
            { 0x720, "Cursor Type / Hover State?" },
            { 0x721, "Cursor X Pos" },
            { 0x722, "Cursor Y Pos" },
            { 0x724, "Cursor Type / Hover State?" },
            { 0x725, "Cursor X Pos" },
            { 0x726, "Cursor Y Pos" },
            { 0x728, "Cursor Type / Hover State?" },
            { 0x729, "Cursor X Pos" },
            { 0x72A, "Cursor Y Pos" },
        } );

        //public static readonly LuaPool Pool2 = new( 2, 32, [] );
        //public static readonly LuaPool Pool3 = new( 3, 32, [] );
        public static List<LuaPool> Pools => [
            Pool1
        ];
    }
}
