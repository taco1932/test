using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Utility.Raii;
using System.IO;
using System.Numerics;
using VfxEditor.FileManager;
using VfxEditor.Spawn;
using VfxEditor.Utils;

namespace VfxEditor.CutbFormat {
    public class CutbDocument : FileManagerBasicDocument<CutbFile> {
        public override string Id => "Cutb";
        public override string Extension => "Cutb";

        public uint AnimationId = 0;
        private bool AnimationDisabled => string.IsNullOrEmpty( ReplacePath ) || AnimationId == 0;

        public CutbDocument( CutbManager manager, string writeLocation ) : base( manager, writeLocation ) { }

        public CutbDocument( CutbManager manager, string writeLocation, string localPath, WorkspaceMetaBasic data ) : base( manager, writeLocation, localPath, data ) { }


        protected override CutbFile FileFromReader( BinaryReader reader, bool verify ) => new( reader, verify );

        protected override void DrawExtraColumn() {
            using var framePadding = ImRaii.PushStyle( ImGuiStyleVar.FramePadding, new Vector2( 4, 3 ) );
            using( var group = ImRaii.Group() ) {
                using( var style = ImRaii.PushStyle( ImGuiStyleVar.Alpha, ImGui.GetStyle().Alpha * 0.5f, AnimationDisabled ) ) {
                    if( ImGui.Button( "Play", new Vector2( 90, ImGui.GetFrameHeight() ) ) && !AnimationDisabled ) CutbSpawn.Apply( AnimationId );
                }

                if( ImGui.Button( "Reset", new Vector2( 90, ImGui.GetFrameHeight() ) ) ) CutbSpawn.Reset();
            }

            var height = ImGui.GetItemRectSize().Y;

            using( var _ = ImRaii.PushStyle( ImGuiStyleVar.ItemSpacing, new Vector2( ImGui.GetStyle().ItemSpacing.Y, 4 ) ) ) {
                ImGui.SameLine();
            }
            Plugin.TrackerManager.Cutb.DrawEye( new Vector2( 28, height ) );
        }

        protected override void DrawBody() {
            ImGui.SetCursorPosY( ImGui.GetCursorPosY() + 5 );
            DrawAnimationWarning();
            base.DrawBody();
        }
    }
}